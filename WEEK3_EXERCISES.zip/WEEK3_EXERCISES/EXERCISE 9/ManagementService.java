package com.example.employeemanagementsystem.service;

import com.example.employeemanagementsystem.model.primary.Employee;
import com.example.employeemanagementsystem.repository.primary.EmployeeRepository;
import com.example.employeemanagementsystem.model.secondary.Department;
import com.example.employeemanagementsystem.repository.secondary.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ManagementService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Department saveDepartment(Department department) {
        return departmentRepository.save(department);
    }
}
