package com.example.employeemanagementsystem.controller;

import com.example.employeemanagementsystem.model.Employee;
import com.example.employeemanagementsystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @GetMapping("/department/{departmentName}")
    public List<Employee> getEmployeesByDepartmentName(@PathVariable String departmentName) {
        return employeeService.findEmployeesByDepartmentName(departmentName);
    }

    @GetMapping("/name-pattern/{pattern}")
    public List<Employee> getEmployeesByNamePattern(@PathVariable String pattern) {
        return employeeService.findEmployeesByNamePattern(pattern);
    }

    @GetMapping("/email-domain/{domain}")
    public List<Employee> getEmployeesByEmailDomain(@PathVariable String domain) {
        return employeeService.findEmployeesByEmailDomain(domain);
    }

    @GetMapping("/named/department/{departmentId}")
    public List<Employee> getEmployeesByDepartmentIdNamed(@PathVariable Long departmentId) {
        return employeeService.findEmployeesByDepartmentId(departmentId);
    }

    @GetMapping("/named/name/{name}")
    public List<Employee> getEmployeesByNameIgnoreCase(@PathVariable String name) {
        return employeeService.findEmployeesByNameIgnoreCase(name);
    }
}
