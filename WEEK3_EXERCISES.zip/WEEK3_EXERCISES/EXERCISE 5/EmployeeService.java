package com.example.employeemanagementsystem.service;

import com.example.employeemanagementsystem.model.Employee;
import com.example.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> findEmployeesByDepartmentName(String departmentName) {
        return employeeRepository.findEmployeesByDepartmentName(departmentName);
    }

    public List<Employee> findEmployeesByNamePattern(String namePattern) {
        return employeeRepository.findEmployeesByNamePattern(namePattern);
    }

    public List<Employee> findEmployeesByEmailDomain(String domain) {
        return employeeRepository.findEmployeesByEmailDomain(domain);
    }

    public List<Employee> findEmployeesByDepartmentId(Long departmentId) {
        return employeeRepository.findByDepartmentId(departmentId);
    }

    public List<Employee> findEmployeesByNameIgnoreCase(String name) {
        return employeeRepository.findByNameIgnoreCase(name);
    }
}
