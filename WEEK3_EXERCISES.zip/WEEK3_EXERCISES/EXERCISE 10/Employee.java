package com.example.employeemanagementsystem.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.NaturalId;
import org.hibernate.annotations.Type;

@Entity
@Table(name = "employees")
@Data
@NoArgsConstructor
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "department_id")
    private Department department;

    @NaturalId
    @Column(unique = true, nullable = false)
    private String employeeCode;

    @Type(type = "org.hibernate.type.StringType")
    @Column(columnDefinition = "TEXT")
    private String description;

    @BatchSize(size = 50)
    @OneToMany(mappedBy = "employee", fetch = FetchType.LAZY)
    private List<Task> tasks;
}
