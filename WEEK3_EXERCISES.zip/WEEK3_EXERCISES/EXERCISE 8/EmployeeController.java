package com.example.employeemanagementsystem.controller;

import com.example.employeemanagementsystem.dto.EmployeeDTO;
import com.example.employeemanagementsystem.projection.EmployeeProjection;
import com.example.employeemanagementsystem.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;
    @GetMapping("/projections/department/{departmentName}")
    public List<EmployeeProjection> getEmployeesByDepartmentNameProjection(@PathVariable String departmentName) {
        return employeeService.findEmployeesByDepartmentNameProjection(departmentName);
    }
    @GetMapping("/dtos/department/{departmentName}")
    public List<EmployeeDTO> getEmployeesByDepartmentNameDTO(@PathVariable String departmentName) {
        return employeeService.findEmployeesByDepartmentNameDTO(departmentName);
    }
}
