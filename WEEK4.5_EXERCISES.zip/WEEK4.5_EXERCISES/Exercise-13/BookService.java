import org.springframework.stereotype.Service;

@Service
public class BookService {

    public Book getBookById(Long id) {
        // Implementation
    }

    public Book createBook(Book book) {
    }
}
