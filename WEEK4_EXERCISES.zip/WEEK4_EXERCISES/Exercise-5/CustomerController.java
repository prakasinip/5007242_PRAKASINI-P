package com.example.bookstoreapi;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private List<Customer> customers = new ArrayList<>();

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        customers.add(customer);
        
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "CustomerCreated");
        
        return new ResponseEntity<>(customer, headers, HttpStatus.CREATED);
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<Customer> registerCustomer(@RequestParam String name,
                                                     @RequestParam String email,
                                                     @RequestParam String address) {
        Customer customer = new Customer((long) (customers.size() + 1), name, email, address);
        customers.add(customer);
        
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "CustomerRegistered");
        
        return new ResponseEntity<>(customer, headers, HttpStatus.CREATED);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<Customer>> getAllCustomers() {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "CustomerListFetched");
        
        return new ResponseEntity<>(customers, headers, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable Long id) {
        return customers.stream()
                .filter(customer -> customer.getId().equals(id))
                .findFirst()
                .map(customer -> {
                    HttpHeaders headers = new HttpHeaders();
                    headers.add("Custom-Header", "CustomerFetched");
                    return new ResponseEntity<>(customer, headers, HttpStatus.OK);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        boolean removed = customers.removeIf(customer -> customer.getId().equals(id));
        
        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", removed ? "CustomerDeleted" : "CustomerNotFound");
        
        return new ResponseEntity<>(headers, removed ? HttpStatus.NO_CONTENT : HttpStatus.NOT_FOUND);
    }
}
