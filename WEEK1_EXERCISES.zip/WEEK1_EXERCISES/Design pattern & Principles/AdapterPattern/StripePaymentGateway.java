public class StripePaymentGateway {
    public void makeStripePayment(double amount) {
        System.out.println("Processing payment of $" + amount + " through Stripe.");
    }
}