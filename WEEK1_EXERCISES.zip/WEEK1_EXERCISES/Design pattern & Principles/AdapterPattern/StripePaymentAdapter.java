public class StripePaymentAdapter implements PaymentProcessor {
    private StripePaymentGateway stripeGateway;

    public StripePaymentAdapter(StripePaymentGateway stripeGateway) {
        this.stripeGateway = stripeGateway;
    }

    @Override
    public void processPayment(double amount) {
        stripeGateway.makeStripePayment(amount);
    }
}