public class PaypalPaymentAdapter implements PaymentProcessor {
    private PaypalPaymentGateway paypalGateway;

    public PaypalPaymentAdapter(PaypalPaymentGateway paypalGateway) {
        this.paypalGateway = paypalGateway;
    }

    @Override
    public void processPayment(double amount) {
        paypalGateway.makePaypalPayment(amount);
    }
}