public class TestAdapterPattern {
    public static void main(String[] args) {
        StripePaymentGateway stripeGateway = new StripePaymentGateway();
        PaymentProcessor stripeProcessor = new StripePaymentAdapter(stripeGateway);
        stripeProcessor.processPayment(100.0);

        PaypalPaymentGateway paypalGateway = new PaypalPaymentGateway();
        PaymentProcessor paypalProcessor = new PaypalPaymentAdapter(paypalGateway);
        paypalProcessor.processPayment(200.0);
    }
}
