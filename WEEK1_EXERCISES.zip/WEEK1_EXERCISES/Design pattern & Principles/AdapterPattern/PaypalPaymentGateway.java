public class PaypalPaymentGateway {
    public void makePaypalPayment(double amount) {
        System.out.println("Processing payment of $" + amount + " through PayPal.");
    }
}