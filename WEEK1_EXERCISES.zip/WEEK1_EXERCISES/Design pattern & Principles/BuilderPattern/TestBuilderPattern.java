public class TestBuilderPattern {
    public static void main(String[] args) {
        Computer basicComputer = new Computer.Builder()
            .setCPU("Intel i5")
            .setRAM("8GB")
            .setStorage("256GB SSD")
            .build();

        Computer gamingComputer = new Computer.Builder()
            .setCPU("Intel i9")
            .setRAM("32GB")
            .setStorage("1TB SSD")
            .setGraphicsCard("NVIDIA RTX 3080")
            .setPowerSupply("750W")
            .setMotherboard("ASUS ROG")
            .build();

        Computer workstationComputer = new Computer.Builder()
            .setCPU("AMD Ryzen 9")
            .setRAM("64GB")
            .setStorage("2TB NVMe SSD")
            .setGraphicsCard("NVIDIA Quadro RTX 4000")
            .setPowerSupply("850W")
            .setMotherboard("MSI Creator")
            .build();

        System.out.println("Basic Computer Configuration:");
        System.out.println("CPU: " + basicComputer.getCPU());
        System.out.println("RAM: " + basicComputer.getRAM());
        System.out.println("Storage: " + basicComputer.getStorage());
        System.out.println();

        System.out.println("Gaming Computer Configuration:");
        System.out.println("CPU: " + gamingComputer.getCPU());
        System.out.println("RAM: " + gamingComputer.getRAM());
        System.out.println("Storage: " + gamingComputer.getStorage());
        System.out.println("Graphics Card: " + gamingComputer.getGraphicsCard());
        System.out.println("Power Supply: " + gamingComputer.getPowerSupply());
        System.out.println("Motherboard: " + gamingComputer.getMotherboard());
        System.out.println();

        System.out.println("Workstation Computer Configuration:");
        System.out.println("CPU: " + workstationComputer.getCPU());
        System.out.println("RAM: " + workstationComputer.getRAM());
        System.out.println("Storage: " + workstationComputer.getStorage());
        System.out.println("Graphics Card: " + workstationComputer.getGraphicsCard());
        System.out.println("Power Supply: " + workstationComputer.getPowerSupply());
        System.out.println("Motherboard: " + workstationComputer.getMotherboard());
    }
}
