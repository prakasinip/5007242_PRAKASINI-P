import java.util.HashMap;

public class InventoryManagement {
    private HashMap<String, product> inventory;

    public InventoryManagement() {
        inventory = new HashMap<>();
    }

    // Add a product
    public void addProduct(product product) {
        inventory.put(product.getProductId(), product);
    }

    // Update a product
    public void updateProduct(String productId, String productName, int quantity, double price) {
        product product = inventory.get(productId);
        if (product != null) {
            product.setProductName(productName);
            product.setQuantity(quantity);
            product.setPrice(price);
        } else {
            System.out.println("Product not found!");
        }
    }

    // Delete a product
    public void deleteProduct(String productId) {
        inventory.remove(productId);
    }

    // Display inventory
    public void displayInventory() {
        for (product product : inventory.values()) {
            System.out.println(product);
        }
    }

    public static void main(String[] args) {
        InventoryManagement im = new InventoryManagement();
        
        product p1 = new product("1", "Laptop", 10, 1500.0);
        product p2 = new product("2", "Mouse", 50, 25.0);
        
        im.addProduct(p1);
        im.addProduct(p2);
        
        im.displayInventory();
        
        im.updateProduct("1", "Laptop Pro", 8, 1600.0);
        im.deleteProduct("2");
        
        im.displayInventory();
    }
}
