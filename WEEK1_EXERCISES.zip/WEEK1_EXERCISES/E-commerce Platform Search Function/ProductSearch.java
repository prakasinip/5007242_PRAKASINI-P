import java.util.Arrays;

public class ProductSearch {
    private product_ecommerce[] products;

    public ProductSearch(product_ecommerce[] products) {
        this.products = products;
    }

    // Linear Search
    public product_ecommerce linearSearch(String productName) {
        for (product_ecommerce product : products) {
            if (product.getProductName().equalsIgnoreCase(productName)) {
                return product;
            }
        }
        return null; // Product not found
    }

    // Binary Search
    public product_ecommerce binarySearch(String productName) {
        Arrays.sort(products); // Ensure the array is sorted
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = (left + right) / 2;
            int comparison = products[mid].getProductName().compareToIgnoreCase(productName);

            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null; // Product not found
    }

    public static void main(String[] args) {
    	product_ecommerce[] products = {
            new product_ecommerce("1", "Laptop", "Electronics"),
            new product_ecommerce("2", "Smartphone", "Electronics"),
            new product_ecommerce("3", "Book", "Literature"),
            new product_ecommerce("4", "Tablet", "Electronics")
        };

        ProductSearch search = new ProductSearch(products);
        
        // Linear Search
        product_ecommerce result = search.linearSearch("Smartphone");
        if (result != null) {
            System.out.println("Linear Search Found: " + result);
        } else {
            System.out.println("Linear Search: Product not found");
        }

        // Binary Search
        result = search.binarySearch("Tablet");
        if (result != null) {
            System.out.println("Binary Search Found: " + result);
        } else {
            System.out.println("Binary Search: Product not found");
        }
    }
}
