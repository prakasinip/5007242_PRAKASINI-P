public class TaskLinkedList {
    private Node head;

    public TaskLinkedList() {
        this.head = null;
    }

    // Add a task to the list
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Search for a task by taskId
    public Task searchTask(String taskId) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId().equals(taskId)) {
                return current.task;
            }
            current = current.next;
        }
        return null; // Task not found
    }

    // Traverse the list and print tasks
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task);
            current = current.next;
        }
    }

    // Delete a task by taskId
    public void deleteTask(String taskId) {
        if (head == null) {
            return;
        }

        if (head.task.getTaskId().equals(taskId)) {
            head = head.next;
            return;
        }

        Node current = head;
        while (current.next != null && !current.next.task.getTaskId().equals(taskId)) {
            current = current.next;
        }

        if (current.next != null) {
            current.next = current.next.next;
        } else {
            System.out.println("Task not found.");
        }
    }

    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        Task t1 = new Task("T1", "Design System Architecture", "Pending");
        Task t2 = new Task("T2", "Develop User Interface", "In Progress");
        Task t3 = new Task("T3", "Implement Backend Logic", "Completed");

        taskList.addTask(t1);
        taskList.addTask(t2);
        taskList.addTask(t3);

        System.out.println("Traversing Tasks:");
        taskList.traverseTasks();

        System.out.println("\nSearching for Task with ID T2:");
        Task searchResult = taskList.searchTask("T2");
        if (searchResult != null) {
            System.out.println("Found: " + searchResult);
        } else {
            System.out.println("Task not found.");
        }

        System.out.println("\nDeleting Task with ID T2:");
        taskList.deleteTask("T2");

        System.out.println("\nTraversing Tasks after Deletion:");
        taskList.traverseTasks();
    }
}
