import java.util.Arrays;

public class LibraryManagementSystem {
    private Book[] books;

    public LibraryManagementSystem(Book[] books) {
        this.books = books;
    }

    // Linear Search
    public Book linearSearch(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null; // Book not found
    }

    // Binary Search
    public Book binarySearch(String title) {
        Arrays.sort(books); // Ensure the array is sorted
        int left = 0;
        int right = books.length - 1;

        while (left <= right) {
            int mid = (left + right) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);

            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null; // Book not found
    }

    public static void main(String[] args) {
        Book[] books = {
            new Book("B1", "The Great Gatsby", "F. Scott Fitzgerald"),
            new Book("B2", "To Kill a Mockingbird", "Harper Lee"),
            new Book("B3", "1984", "George Orwell"),
            new Book("B4", "Moby Dick", "Herman Melville")
        };

        LibraryManagementSystem library = new LibraryManagementSystem(books);
        
        // Linear Search
        Book result = library.linearSearch("1984");
        if (result != null) {
            System.out.println("Linear Search Found: " + result);
        } else {
            System.out.println("Linear Search: Book not found");
        }

        // Binary Search
        result = library.binarySearch("The Great Gatsby");
        if (result != null) {
            System.out.println("Binary Search Found: " + result);
        } else {
            System.out.println("Binary Search: Book not found");
        }
    }
}
