import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public String login(@RequestBody UserLoginRequest loginRequest) {
        // Validate credentials and generate token
        return jwtUtil.generateToken(loginRequest.getUsername());
    }
}
