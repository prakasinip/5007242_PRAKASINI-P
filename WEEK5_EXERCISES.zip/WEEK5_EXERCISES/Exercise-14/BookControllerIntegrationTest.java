import com.example.demo.model.Book;
import com.example.demo.repository.BookRepository;
import com.example.demo.service.BookService;
import com.example.demo.controller.BookController;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@ActiveProfiles("test")
@AutoConfigureTestDatabase(replace = Replace.ANY) // Use H2 for tests
public class BookControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BookRepository bookRepository;

    @BeforeEach
    public void setup() {
        bookRepository.deleteAll(); // Clear the database before each test
    }

    @Test
    public void testCreateBook() throws Exception {
        String bookJson = "{\"title\":\"New Book\", \"author\":\"Author Name\"}";

        mockMvc.perform(post("/books")
                .contentType("application/json")
                .content(bookJson))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.title").value("New Book"))
            .andExpect(jsonPath("$.author").value("Author Name"));
    }

    @Test
    public void testGetBook() throws Exception {
        Book book = new Book();
        book.setTitle("Existing Book");
        book.setAuthor("Author Name");
        bookRepository.save(book);

        mockMvc.perform(get("/books/" + book.getId()))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.title").value("Existing Book"))
            .andExpect(jsonPath("$.author").value("Author Name"));
    }
}
