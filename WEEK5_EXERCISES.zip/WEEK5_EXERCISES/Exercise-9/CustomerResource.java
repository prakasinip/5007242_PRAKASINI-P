import org.springframework.hateoas.RepresentationModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;

public class CustomerResource extends RepresentationModel<CustomerResource> {

    private Long id;
    private String name;
    private Integer age;


    public CustomerResource(Customer customer) {
        this.id = customer.getId();
        this.name = customer.getName();
        this.age = customer.getAge();
        
        add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class).getCustomer(id)).withSelfRel());
    }
}
